A plain archive of two text files.
